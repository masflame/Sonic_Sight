import 'package:flutter/material.dart';
import 'package:flutter_sound/flutter_sound.dart';

class SoundRecognitionService {
  final Map<String, String> soundLabels = {
    'audio/dog_bark1.mp3': 'Dog Bark',
    'audio/siren1.mp3': 'Siren',
    'audio/knock1.mp3': 'Knock',
  };

  String recognizeSound(String audioFilePath) {
    return soundLabels[audioFilePath] ?? "Unknown Sound";
  }
}

class SpeechToTextPage extends StatefulWidget {
  @override
  _SpeechToTextPageState createState() => _SpeechToTextPageState();
}

class _SpeechToTextPageState extends State<SpeechToTextPage> {
  final SoundRecognitionService _soundRecognitionService = SoundRecognitionService();
  final FlutterSoundRecorder _recorder = FlutterSoundRecorder();
  String _recognizedSound = '';

  @override
  void initState() {
    super.initState();
    _initRecorder();
  }

  Future<void> _initRecorder() async {
    await _recorder.openRecorder();
  }

  void _startListening() async {
    await _recorder.startRecorder(toFile: 'audio.aac');
    // Start processing audio in a loop
    _processAudio();
  }

  void _processAudio() async {
    // Simulate recognition after 3 seconds (recording time)
    await Future.delayed(Duration(seconds: 3));

    // Here you should actually use the recorded audio file for recognition
    String recognizedSound = _soundRecognitionService.recognizeSound('audio/dog_bark1.mp3'); // Change this to your logic
    setState(() {
      _recognizedSound = recognizedSound;
    });
  }

  void _stopListening() async {
    await _recorder.stopRecorder();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sound Recognition Demo')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Recognized Sound: $_recognizedSound',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: _startListening,
                  child: const Text('Start Recording'),
                ),
                SizedBox(width: 20),
                ElevatedButton(
                  onPressed: _stopListening,
                  child: const Text('Stop Recording'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _recorder.closeRecorder();
    super.dispose();
  }
}
