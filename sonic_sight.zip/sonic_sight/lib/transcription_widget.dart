import 'package:flutter/material.dart';
import 'package:sonic_sight/transcription_service.dart';

class TranscriptionWidget extends StatefulWidget {
  const TranscriptionWidget({super.key});

  @override
  _TranscriptionWidgetState createState() => _TranscriptionWidgetState();
}

class _TranscriptionWidgetState extends State<TranscriptionWidget> {
  final TranscriptionService _transcriptionService = TranscriptionService();
  String _transcription = "";

  @override
  void initState() {
    super.initState();
    _transcriptionService.startListening((result) {
      setState(() {
        _transcription = result;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Real-Time Transcription")),
      body: Center(
        child: Text(_transcription),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _transcriptionService.stopListening();
        },
        child: const Icon(Icons.stop),
      ),
    );
  }
}
