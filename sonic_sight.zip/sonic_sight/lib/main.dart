// lib/main.dart
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:sonic_sight/smart_devices.dart';
//import 'package:sonic_sight/speech_to_text.dart';
import 'package:sonic_sight/transcription_service.dart';
import 'notification_service.dart'; // Ensure correct path
import 'onboarding_tutorial.dart'; // Ensure this is the correct import
import 'emerge_alert.dart'; // Import the EmergeAlertPage

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: 'YOUR_API_KEY', // Replace with your actual API key
      appId: 'YOUR_APP_ID', // Replace with your actual App ID
      messagingSenderId: 'YOUR_MESSAGING_SENDER_ID', // Replace with your Messaging Sender ID
      projectId: 'YOUR_PROJECT_ID', // Replace with your Project ID
    ),
  );

  // Initialize Notification Service
  final NotificationService _notificationService = NotificationService();

  runApp(MyApp(notificationService: _notificationService));
}

class MyApp extends StatelessWidget {
  final NotificationService notificationService;

  const MyApp({Key? key, required this.notificationService}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Deaf Aid App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const OnboardingTutorial(), // Start with onboarding tutorial
      // Define routes for navigation
      routes: {
        '/transcriber': (context) => const TranscriberPage(),
        '/smart_devices': (context) =>  DeviceManagementPage(),
        '/emerge_alert': (context) => EmergeAlertPage(notificationService: notificationService),
        '/notifications': (context) => const NotificationsPage(),
        '/community_feedback': (context) => const CommunityFeedbackPage(),
        // Add more routes as needed
      },
    );
  }
}

// Initialize the notification service
class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final NotificationService _notificationService = NotificationService();

  @override
  void initState() {
    super.initState();
    // Initialize any additional features here
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      appBar: AppBar(
        // Remove "Home" text and add hamburger icon
        leading: Builder(
          builder: (context) => IconButton(
            icon: Image.asset("icons/menu.png"), // Ensure correct path
            onPressed: () {
              // Handle hamburger menu press, e.g., open a drawer
              Scaffold.of(context).openDrawer();
            },
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () {
              // Handle notification press
              Navigator.pushNamed(context, '/notifications');
            },
          ),
        ],
      ),
      drawer: Drawer(
        // Implement your drawer here
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Deaf Aid App',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.home),
              title: const Text('Home'),
              onTap: () {
                Navigator.pop(context); // Close the drawer
                // Navigate to Home if not already there
              },
            ),
            // Add more drawer items here
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              // Welcome Banner
              Container(
                padding: const EdgeInsets.all(20.0),
                decoration: BoxDecoration(
                  color: Colors.blue[100],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text(
                  'Welcome to Sonic Sight!',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 20),

              // Analytics Overview Row
              Column(
                children: [

                  Container(
                    decoration: BoxDecoration(
                      color: Colors.red[800], // Change to your desired background color
                      borderRadius: BorderRadius.circular(20), // Adjust the curvature
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 2,
                          blurRadius: 5,
                          offset: const Offset(0, 3), // Changes position of shadow
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.all(16.0), // Add padding for spacing
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Analytics Overview",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 4),
                            Text("Most recorded sound: Cat meow"),
                            Text("Incidents: 2"),
                            Text("Interaction: 4"),
                          ],
                        ),
                        Image.asset(
                          "icons/dashboard.png", // Ensure correct path
                          width: 0,
                        ),
                      ],
                    ),
                  ),


                  const SizedBox(height: 20),

                  // Features section with clickable cards
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildFeatureCard(
                        title: "Transcriber",
                        imagePath: "icons/transcript.png",
                        destination: '/transcriber',
                      ),
                      _buildFeatureCard(
                        title: "Smart Devices",
                        imagePath: "icons/iot.png",
                        destination: '/smart_devices',
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildFeatureCard(
                        title: "Emerge Alert",
                        imagePath: "icons/fire-alarm.png",
                        destination: '/emerge_alert',
                      ),
                      _buildFeatureCard(
                        title: "Notifications",
                        imagePath: "icons/notification.png",
                        destination: '/notifications',
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildFeatureCard(
                        title: "Community Feedback",
                        imagePath: "icons/community.png",
                        destination: '/community_feedback',
                      ),
                      _buildFeatureCard(
                        title: "Awareness mode",
                        imagePath: "icons/iot.png",
                        destination: '/awareness_mode',
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Custom method to build the clickable feature cards
  Widget _buildFeatureCard({
    required String title,
    required String imagePath,
    required String destination,
  }) {
    return InkWell(
      onTap: () {
        Navigator.pushNamed(context, destination);
      },
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: 160,
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(10), // Curved edges
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: const Offset(0, 3), // changes position of shadow
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              height: 60,
              padding: const EdgeInsets.all(8.0),
              child: Image.asset(
                imagePath,
                fit: BoxFit.contain,
              ), // Use your image path
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                title,
                textAlign: TextAlign.center,
                style:
                const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Placeholder pages for navigation

class TranscriberPage extends StatelessWidget {
  const TranscriberPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.red[800],
      appBar: AppBar(
        title: const Text('Transcriber'),
      ),
      body: const Center(
        child: Text(
          'Transcriber Page',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}

class SmartDevicesPage extends StatelessWidget {
  const SmartDevicesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Smart Devices'),
      ),
      body: const Center(
        child: Text(
          'Smart Devices Page',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
      ),
      body: const Center(
        child: Text(
          'Notifications Page',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}

class CommunityFeedbackPage extends StatelessWidget {
  const CommunityFeedbackPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Community Feedback'),
      ),
      body: const Center(
        child: Text(
          'Community Feedback Page',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}

class AwarenessMode extends StatelessWidget {
  const AwarenessMode({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Awareness Mode'),
      ),
      body: const Center(
        child: Text(
          'Awareness Mode',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
