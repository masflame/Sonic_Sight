import 'package:flutter/material.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Help & Support')),
      body: ListView(
        children: const [
          ListTile(
            title: Text("How to set up alerts?"),
            subtitle: Text("Go to Settings > Alerts to customize visual and vibration alerts."),
          ),
          ListTile(
            title: Text("How to add new sound profiles?"),
            subtitle: Text("Navigate to Settings > Sound Profiles to add and manage custom sounds."),
          ),
          // Add more FAQ items here
        ],
      ),
    );
  }
}
