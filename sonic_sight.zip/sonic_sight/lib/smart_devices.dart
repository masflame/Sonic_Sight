import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Device Management',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: DeviceManagementPage(),
    );
  }
}

class DeviceManagementPage extends StatefulWidget {
  @override
  _DeviceManagementPageState createState() => _DeviceManagementPageState();
}

class _DeviceManagementPageState extends State<DeviceManagementPage> {
  final TextEditingController _searchController = TextEditingController();
  final List<String> devices = ["Smart Light", "Thermostat", "Security Camera"]; // Sample device names

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Smart Device Management'),
        actions: [
          IconButton(icon: Icon(Icons.account_circle), onPressed: () {
            // Navigate to profile/settings
          }),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(child: Text('Menu')),
            ListTile(title: Text('Dashboard'), onTap: () {}),
            ListTile(title: Text('Devices'), onTap: () {}),
            ListTile(title: Text('Settings'), onTap: () {}),
            ListTile(title: Text('Help/Support'), onTap: () {}),
          ],
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController, // Set the controller
              decoration: InputDecoration(
                labelText: 'Search devices...',
                border: OutlineInputBorder(),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: devices.length,
              itemBuilder: (context, index) {
                return DeviceCard(deviceName: devices[index]);
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: () {
                // Navigate to add new device page
              },
              child: Text('Add New Device'),
            ),
          ),
        ],
      ),
    );
  }
}

class DeviceCard extends StatelessWidget {
  final String deviceName;

  DeviceCard({required this.deviceName});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: ListTile(
        title: Text(deviceName),
        subtitle: Text('Status: Online'),
        leading: Icon(Icons.device_hub), // Replace with appropriate device icon
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(icon: Icon(Icons.settings), onPressed: () {
              // Open device settings
            }),
            IconButton(icon: Icon(Icons.delete), onPressed: () {
              // Delete device
            }),
          ],
        ),
      ),
    );
  }
}
