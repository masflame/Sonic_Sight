import 'package:speech_to_text/speech_to_text.dart' as stt;

class BackgroundAudioService {
  final stt.SpeechToText _speech = stt.SpeechToText();

  Future<void> startListening(Function(String) onResult) async {
    await _speech.initialize();
    _speech.listen(onResult: (result) {
      if (result.hasConfidenceRating && result.confidence > 0.5) {
        onResult(result.recognizedWords); // Call the callback with recognized words
      }
    });
  }

  void stopListening() {
    _speech.stop();
  }
}
