import 'package:flutter/material.dart';

class SoundProfileSettings extends StatefulWidget {
  const SoundProfileSettings({super.key});

  @override
  _SoundProfileSettingsState createState() => _SoundProfileSettingsState();
}

class _SoundProfileSettingsState extends State<SoundProfileSettings> {
  double _doorbellSensitivity = 0.5;
  double _babyCrySensitivity = 0.7;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Customizable Sound Profiles")),
      body: Column(
        children: [
          ListTile(
            title: const Text('Doorbell'),
            trailing: Slider(
              value: _doorbellSensitivity,
              onChanged: (value) {
                setState(() {
                  _doorbellSensitivity = value;
                });
              },
            ),
          ),
          ListTile(
            title: const Text('Baby Cry'),
            trailing: Slider(
              value: _babyCrySensitivity,
              onChanged: (value) {
                setState(() {
                  _babyCrySensitivity = value;
                });
              },
            ),
          ),
          ElevatedButton(
            onPressed: () {
              // Save profile settings
            },
            child: const Text("Save Settings"),
          )
        ],
      ),
    );
  }
}
