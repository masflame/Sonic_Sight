import 'package:flutter/material.dart';
import 'package:intro_slider/intro_slider.dart';

import 'main.dart';

class OnboardingTutorial extends StatelessWidget {
  const OnboardingTutorial({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IntroSlider(
        onDonePress: () {
          // Navigate to the next page or home screen after onboarding
          Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (context) => const MyHomePage(), // Replace with your home page
          ));
        },
        slides: [
          Slide(
            title: "Welcome to Deaf Aid App",
            description: "Get real-time notifications for sounds around you.",
            pathImage: "icons/home.png",
            backgroundColor: Colors.blue,
          ),
          Slide(
            title: "Customize Alerts",
            description: "Set visual and vibration alerts for specific sounds.",
            pathImage: "icons/home.png",
            backgroundColor: Colors.green,
          ),
          Slide(
            title: "Transcribe Conversations",
            description: "Get real-time captions during conversations or phone calls.",
            pathImage: "icons/home.png",
            backgroundColor: Colors.red,
          ),
        ],
      ),
    );
  }
}
