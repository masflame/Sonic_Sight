import 'package:flutter/material.dart';
import 'package:sonic_sight/security_service.dart';

class PrivacySettings extends StatelessWidget {

  final SecurityService _securityService = SecurityService();

  PrivacySettings({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Privacy Settings")),
      body: ListView(
        children: [
          ListTile(
            title: const Text("Export Data"),
            onTap: () {
              // Logic to export data
            },
          ),
          ListTile(
            title: const Text("Delete Data"),
            onTap: () {
              _securityService.deleteUserPreference('user_data');
            },
          ),
        ],
      ),
    );
  }
}
