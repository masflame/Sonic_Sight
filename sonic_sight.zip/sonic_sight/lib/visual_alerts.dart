import 'package:flutter/material.dart';
import 'package:vibration/vibration.dart';

void showVisualAlert(BuildContext context) {
  const snackBar = SnackBar(
    content: Text('Visual Alert: Sound Detected!'),
    backgroundColor: Colors.redAccent,
  );
  ScaffoldMessenger.of(context).showSnackBar(snackBar);
}

Future<void> showVibrationAlert() async {
  if (await Vibration.hasVibrator() ?? false) {
    Vibration.vibrate(duration: 1000);
  }
}
