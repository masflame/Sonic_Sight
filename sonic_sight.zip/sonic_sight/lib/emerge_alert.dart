// lib/emerge_alert.dart
import 'package:flutter/material.dart';
import 'notification_service.dart';
import 'package:geolocator/geolocator.dart';

class EmergeAlertPage extends StatelessWidget {
  final NotificationService notificationService;

  const EmergeAlertPage({Key? key, required this.notificationService}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Emergency Alert'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            await _triggerPanicAlert(context);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red, // Red color for panic button
            shape: const CircleBorder(),
            padding: const EdgeInsets.all(80), // Size of the button
          ),
          child: const Icon(
            Icons.warning,
            color: Colors.white,
            size: 50,
          ),
        ),
      ),
    );
  }

  Future<void> _triggerPanicAlert(BuildContext context) async {
    // Check and request location permissions
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled don't continue
      // accessing the position and request users of the
      // App to enable the location services.
      await Geolocator.openLocationSettings();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Location services are disabled. Please enable them.'),
        ),
      );
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        // Permissions are denied, next time you could try
        // requesting permissions again (this is also where
        // Android's shouldShowRequestPermissionRationale
        // returned true. According to Android guidelines
        // your App should show an explanatory UI now.
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Location permissions are denied'),
          ),
        );
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              'Location permissions are permanently denied. We cannot request permissions.'),
        ),
      );
      return;
    }

    // When we reach here, permissions are granted and we can
    // continue accessing the position of the device.
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);

    String location = 'Latitude: ${position.latitude}, Longitude: ${position.longitude}';

    // Send a local notification with location
    await notificationService.showNotification(
      title: 'Emergency Alert',
      body: 'A panic alert has been triggered!\nLocation: $location',
    );

    // Display a confirmation dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Alert Sent'),
        content: const Text(
          'Your emergency alert has been sent to your next of kin and emergency services.',
        ),
        actions: [
          TextButton(
            child: const Text('OK'),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );

    // Here, you can add additional functionalities such as sending data to Firebase,
    // sharing location with contacts, etc., if needed.
  }
}
